package com.example1;

//original interface 
public interface Movable {

	// returns speed in MPH
	double getSpeed();

}