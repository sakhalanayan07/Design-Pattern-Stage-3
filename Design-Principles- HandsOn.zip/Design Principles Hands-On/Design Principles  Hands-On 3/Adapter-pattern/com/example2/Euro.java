package com.example2;

// Adapter Interface
public interface Euro {

	// returns currency in euro
	double getCurr();
}
