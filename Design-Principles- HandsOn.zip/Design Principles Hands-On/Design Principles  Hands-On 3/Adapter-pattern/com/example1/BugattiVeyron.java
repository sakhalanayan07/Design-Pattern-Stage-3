package com.example1;

// concrete implementation of the original interface
public class BugattiVeyron implements Movable {

	@Override
	public double getSpeed() {
		return 268;
	}
}